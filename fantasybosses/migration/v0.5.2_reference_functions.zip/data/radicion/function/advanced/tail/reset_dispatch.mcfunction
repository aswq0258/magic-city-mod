$function radicion:advanced/tail/reset/$(ground_frame)
