$function radicion:advanced/tail/strike/$(ground_frame)
