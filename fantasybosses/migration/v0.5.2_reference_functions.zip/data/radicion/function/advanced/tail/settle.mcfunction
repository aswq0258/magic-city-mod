execute store result storage radicion:runtime ground_frame int 1 run scoreboard players get #ground_frame radicion
function radicion:advanced/tail/settle_dispatch with storage radicion:runtime
