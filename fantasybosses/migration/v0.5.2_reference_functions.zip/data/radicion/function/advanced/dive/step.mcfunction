scoreboard players add #dive_step radicion 1
execute store result storage radicion:runtime dive_step int 1 run scoreboard players get #dive_step radicion
function radicion:advanced/dive/dispatch with storage radicion:runtime
execute if score #dive_step radicion matches 24 run function radicion:advanced/dive/impact
execute if score #dive_step radicion matches 42 run function radicion:advanced/dive/finish
