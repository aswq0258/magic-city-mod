execute as @e[type=minecraft:marker,tag=radicion_warning] at @s run particle minecraft:explosion_emitter ~ ~0.7 ~ 0 0 0 0 1 force @a[x=-2895,y=8,z=-895,dx=70,dy=31,dz=70,gamemode=!spectator]
execute as @e[type=minecraft:marker,tag=radicion_warning] at @s run particle minecraft:block{block_state:{Name:"minecraft:rooted_dirt"}} ~ ~0.3 ~ 2.2 .4 2.2 .18 95 force @a[x=-2895,y=8,z=-895,dx=70,dy=31,dz=70,gamemode=!spectator]
execute as @e[type=minecraft:marker,tag=radicion_warning] at @s run particle minecraft:cloud ~ ~0.7 ~ 1.9 .35 1.9 .12 55 force @a[x=-2895,y=8,z=-895,dx=70,dy=31,dz=70,gamemode=!spectator]
execute as @e[type=minecraft:marker,tag=radicion_warning] at @s run playsound minecraft:entity.generic.explode hostile @a[x=-2895,y=8,z=-895,dx=70,dy=31,dz=70,gamemode=!spectator] ~ ~ ~ 4 0.55
execute as @e[type=minecraft:marker,tag=radicion_warning] at @s run playsound minecraft:block.deepslate.break hostile @a[x=-2895,y=8,z=-895,dx=70,dy=31,dz=70,gamemode=!spectator] ~ ~ ~ 3 0.65
function radicion:skills/hit_all
kill @e[type=minecraft:marker,tag=radicion_warning]
title @a[x=-2895,y=8,z=-895,dx=70,dy=31,dz=70,gamemode=!spectator] actionbar {"text":"지면 충돌! 몸통이 내려오는 중입니다.","color":"yellow"}
