execute as @e[type=minecraft:block_display,tag=radicion_body] run data merge entity @s {teleport_duration:2,interpolation_duration:2}
scoreboard players set #route radicion 0
scoreboard players set #air radicion 0
scoreboard players set #request radicion 0
scoreboard players set #ground_frame radicion 24
scoreboard players set #ground_ticks radicion 0
scoreboard players set #clock radicion 0
function radicion:ground/24
function radicion:skills/finish
scoreboard players set #rest radicion 44
title @a[x=-2895,y=8,z=-895,dx=70,dy=31,dz=70,gamemode=!spectator] actionbar {"text":"착지 후 경직 — 반격 기회!","color":"green"}
