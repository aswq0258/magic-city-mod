$function radicion:advanced/dive/frames/$(dive_step)
