scoreboard players set #dying radicion 1
scoreboard players set #death_tick radicion 0
scoreboard players set #skill radicion 0
scoreboard players set #request radicion 0
function radicion:advanced/death/tag_body
kill @e[tag=radicion_owned,tag=!radicion_body,tag=!radicion_head]
function radicion:arena/reset
bossbar set radicion:boss value 0
execute at @e[type=minecraft:block_display,tag=rad_s0_head_base,limit=1] run playsound minecraft:entity.ravager.death hostile @a[x=-2895,y=8,z=-895,dx=70,dy=31,dz=70,gamemode=!spectator] ~ ~ ~ 1.8 0.65
title @a[x=-2895,y=8,z=-895,dx=70,dy=31,dz=70,gamemode=!spectator] actionbar {"text":"세계수의 마력이 기생체에서 빠져나갑니다...","color":"green"}
