scoreboard players add #death_tick radicion 1
execute if score #death_tick radicion matches 4 run function radicion:advanced/death/segment/10
execute if score #death_tick radicion matches 8 run function radicion:advanced/death/segment/9
execute if score #death_tick radicion matches 12 run function radicion:advanced/death/segment/8
execute if score #death_tick radicion matches 16 run function radicion:advanced/death/segment/7
execute if score #death_tick radicion matches 20 run function radicion:advanced/death/segment/6
execute if score #death_tick radicion matches 24 run function radicion:advanced/death/segment/5
execute if score #death_tick radicion matches 28 run function radicion:advanced/death/segment/4
execute if score #death_tick radicion matches 32 run function radicion:advanced/death/segment/3
execute if score #death_tick radicion matches 36 run function radicion:advanced/death/segment/2
execute if score #death_tick radicion matches 40 run function radicion:advanced/death/segment/1
execute if score #death_tick radicion matches 44 run function radicion:advanced/death/segment/0
execute if score #death_tick radicion matches 48.. run function radicion:victory
