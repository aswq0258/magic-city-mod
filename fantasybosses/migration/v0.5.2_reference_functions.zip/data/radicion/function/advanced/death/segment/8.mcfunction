execute at @e[type=minecraft:block_display,tag=rad_s8,limit=1] run particle minecraft:dust{color:[0.55,0.95,0.25],scale:1.3} ~ ~ ~ .55 .45 .55 0 18 force @a[x=-2895,y=8,z=-895,dx=70,dy=31,dz=70,gamemode=!spectator]
execute at @e[type=minecraft:block_display,tag=rad_s8,limit=1] run particle minecraft:poof ~ ~ ~ .45 .35 .45 .04 10 force @a[x=-2895,y=8,z=-895,dx=70,dy=31,dz=70,gamemode=!spectator]
kill @e[type=minecraft:block_display,tag=rad_s8]
