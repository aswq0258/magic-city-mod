function radicion:arena/clear_roots
data merge entity @e[type=minecraft:ravager,tag=radicion_head,limit=1] {Invulnerable:0b}
kill @e[type=minecraft:ravager,tag=radicion_head,limit=1]
function radicion:advanced/death/start
