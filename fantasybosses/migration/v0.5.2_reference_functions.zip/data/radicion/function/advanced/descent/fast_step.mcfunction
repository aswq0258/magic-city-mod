scoreboard players add #frame radicion 2
execute if score #frame radicion matches 259.. run scoreboard players set #frame radicion 259
function radicion:move
function radicion:advanced/descent/trail
