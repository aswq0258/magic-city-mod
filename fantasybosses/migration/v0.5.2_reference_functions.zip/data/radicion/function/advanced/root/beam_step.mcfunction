scoreboard players add #beam_steps radicion 1
particle minecraft:dust{color:[0.30,0.95,0.10],scale:1.6} ~ ~ ~ .08 .08 .08 0 1 force @a[x=-2895,y=8,z=-895,dx=70,dy=31,dz=70,gamemode=!spectator]
scoreboard players operation #beam_mod radicion = #beam_steps radicion
scoreboard players operation #beam_mod radicion -= #beam_phase radicion
scoreboard players operation #beam_mod radicion %= #beam_six radicion
execute if score #beam_mod radicion matches 0 run particle minecraft:dust{color:[0.88,1.0,0.45],scale:2.3} ~ ~ ~ .10 .10 .10 0 2 force @a[x=-2895,y=8,z=-895,dx=70,dy=31,dz=70,gamemode=!spectator]
execute if score #beam_steps radicion matches 1..72 unless entity @e[type=minecraft:block_display,tag=rad_s10_tail,distance=..1.3,limit=1] positioned ^ ^ ^1 run function radicion:advanced/root/beam_step
