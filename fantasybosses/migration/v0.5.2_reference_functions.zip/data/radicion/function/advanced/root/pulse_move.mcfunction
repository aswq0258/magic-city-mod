scoreboard players add @s radicion 1
execute if score @s radicion matches ..100 facing entity @e[type=minecraft:block_display,tag=rad_s10_tail,limit=1] feet run tp @s ^ ^ ^0.85
execute at @s if block ~ ~ ~ #radicion:empty_space run particle minecraft:dust{color:[0.35,0.85,0.12],scale:1.0} ~ ~ ~ 0.10 0.10 0.10 0 3 force @a[x=-2895,y=8,z=-895,dx=70,dy=31,dz=70,gamemode=!spectator]
execute at @s if entity @e[type=minecraft:block_display,tag=rad_s10_tail,distance=..1.25,limit=1] run function radicion:advanced/root/pulse_arrive
execute if score @s radicion matches 101.. run kill @s
