particle minecraft:happy_villager ~ ~ ~ .35 .35 .35 0 10 force @a[x=-2895,y=8,z=-895,dx=70,dy=31,dz=70,gamemode=!spectator]
kill @s
