scoreboard players set #beam_steps radicion 0
particle minecraft:dust{color:[0.63,1.0,0.18],scale:1.8} ~ ~ ~ .2 .25 .2 0 5 force @a[x=-2895,y=8,z=-895,dx=70,dy=31,dz=70,gamemode=!spectator]
execute facing entity @e[type=minecraft:block_display,tag=rad_s10_tail,limit=1] feet run function radicion:advanced/root/beam_step
