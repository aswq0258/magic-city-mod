execute unless entity @e[type=minecraft:marker,tag=rad_root_anchor1] run kill @e[type=minecraft:marker,tag=rad_mana_from1]
execute unless entity @e[type=minecraft:marker,tag=rad_root_anchor2] run kill @e[type=minecraft:marker,tag=rad_mana_from2]
execute unless entity @e[type=minecraft:marker,tag=rad_root_anchor3] run kill @e[type=minecraft:marker,tag=rad_mana_from3]
execute unless entity @e[type=minecraft:marker,tag=rad_root_anchor4] run kill @e[type=minecraft:marker,tag=rad_mana_from4]
execute unless entity @e[type=minecraft:block_display,tag=rad_s10_tail,limit=1] run kill @e[type=minecraft:marker,tag=rad_mana_pulse]
execute as @e[type=minecraft:marker,tag=rad_mana_pulse] at @s run function radicion:advanced/root/pulse_move
