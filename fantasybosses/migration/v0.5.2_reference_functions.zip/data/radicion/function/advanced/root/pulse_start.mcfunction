kill @e[type=minecraft:marker,tag=rad_mana_pulse]
execute at @e[type=minecraft:marker,tag=rad_root_anchor1,limit=1] run summon minecraft:marker ~ ~1.2 ~ {Tags:["radicion_owned","rad_mana_pulse","rad_mana_from1"]}
execute at @e[type=minecraft:marker,tag=rad_root_anchor2,limit=1] run summon minecraft:marker ~ ~1.2 ~ {Tags:["radicion_owned","rad_mana_pulse","rad_mana_from2"]}
execute at @e[type=minecraft:marker,tag=rad_root_anchor3,limit=1] run summon minecraft:marker ~ ~1.2 ~ {Tags:["radicion_owned","rad_mana_pulse","rad_mana_from3"]}
execute at @e[type=minecraft:marker,tag=rad_root_anchor4,limit=1] run summon minecraft:marker ~ ~1.2 ~ {Tags:["radicion_owned","rad_mana_pulse","rad_mana_from4"]}
scoreboard players set @e[type=minecraft:marker,tag=rad_mana_pulse] radicion 0
