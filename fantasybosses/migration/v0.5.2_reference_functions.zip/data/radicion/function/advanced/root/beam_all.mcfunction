scoreboard players set #beam_clock radicion 0
scoreboard players set #beam_six radicion 6
scoreboard players add #beam_phase radicion 1
execute if score #beam_phase radicion matches 6.. run scoreboard players set #beam_phase radicion 0
execute if score #root1 radicion matches 1 at @e[type=minecraft:marker,tag=rad_root_anchor1,limit=1] positioned ~ ~1.3 ~ if entity @e[type=minecraft:block_display,tag=rad_s10_tail,limit=1] run function radicion:advanced/root/beam_start
execute if score #root2 radicion matches 1 at @e[type=minecraft:marker,tag=rad_root_anchor2,limit=1] positioned ~ ~1.3 ~ if entity @e[type=minecraft:block_display,tag=rad_s10_tail,limit=1] run function radicion:advanced/root/beam_start
execute if score #root3 radicion matches 1 at @e[type=minecraft:marker,tag=rad_root_anchor3,limit=1] positioned ~ ~1.3 ~ if entity @e[type=minecraft:block_display,tag=rad_s10_tail,limit=1] run function radicion:advanced/root/beam_start
execute if score #root4 radicion matches 1 at @e[type=minecraft:marker,tag=rad_root_anchor4,limit=1] positioned ~ ~1.3 ~ if entity @e[type=minecraft:block_display,tag=rad_s10_tail,limit=1] run function radicion:advanced/root/beam_start
