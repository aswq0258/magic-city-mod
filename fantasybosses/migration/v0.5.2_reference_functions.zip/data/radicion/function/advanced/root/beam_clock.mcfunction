scoreboard players add #beam_clock radicion 1
execute if score #beam_clock radicion matches 8.. run function radicion:advanced/root/beam_all
