execute unless entity @a[x=-2895,y=8,z=-895,dx=70,dy=31,dz=70,gamemode=!spectator] run function radicion:stop_here
execute if score #active radicion matches 1 if score #dying radicion matches 1 run function radicion:advanced/death/tick
execute if score #active radicion matches 1 if score #dying radicion matches 0 unless entity @e[type=minecraft:ravager,tag=radicion_head,limit=1] if entity @e[type=minecraft:block_display,tag=rad_s0_head_base,limit=1] run function radicion:advanced/death/start
execute if score #active radicion matches 1 if score #dying radicion matches 0 unless entity @e[type=minecraft:ravager,tag=radicion_head,limit=1] run function radicion:stop_here
execute if score #active radicion matches 1 if score #dying radicion matches 0 if entity @e[type=minecraft:ravager,tag=radicion_head,limit=1,nbt={Health:0.0f}] run function radicion:advanced/death/start
execute if score #active radicion matches 1 if score #dying radicion matches 0 store result score #hp radicion run data get entity @e[type=minecraft:ravager,tag=radicion_head,limit=1] Health 1
execute if score #active radicion matches 1 if score #dying radicion matches 0 run function radicion:fight
